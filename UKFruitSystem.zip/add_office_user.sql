-- Run once in phpMyAdmin (SQL tab) so there is an account that goes to the OFFICE section.
-- Login: office_clerk / office   (stored as MD5, upgraded to a stronger hash on first login)
USE uk_fruits;
INSERT IGNORE INTO users (username, password, role)
VALUES ('office_clerk', MD5('office'), 'office_clerk');
